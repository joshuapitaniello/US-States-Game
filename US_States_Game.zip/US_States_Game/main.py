import pandas
from turtle import Screen, Turtle

# custom files
from print import Print

# Game variables
total_correct = 0


# Screen Setup
screen = Screen()
screen.title("U.S.A Guess Game")
screen.setup(width=800, height=550)
screen.bgpic("blank_states_img.gif")

# read data with pandas
data = pandas.read_csv("50_states.csv")

# initialize a dictionary to keep count of each color
states = {
    "State Name": data.state.to_list(),
    "X": data.x.to_list(),
    "Y": data.y.to_list()
}


while len(states) > 0:
    # ask for user input
    answer_state = screen.textinput("Your answer", "Enter a state name:\nenter 'Give Up' to see answers").title()
    if answer_state != "Give Up":  # Make sure there's an input to prevent an attribute error on NoneType
        answer_state = answer_state.strip().title().replace(" ", "")  # Strip, title-case, and remove all spaces

    if answer_state == "Exit":  # If the user types 'exit', end the loop
        break

    if answer_state in states['State Name']:
        # find and print the state
        index = states['State Name'].index(answer_state)
        state_name = states['State Name'][index]
        x_cor = states['X'][index]
        y_cor = states['Y'][index]
        printer = Print(state_name, x_cor, y_cor)

        # remove state
        states['State Name'].pop(index)
        states['X'].pop(index)
        states['Y'].pop(index)

        # increase score
        total_correct += 1

    if answer_state == 'Give Up':
        # print out names at locations
        for i in range(len(states['State Name'])):
            state_name = states['State Name'][i]
            x_cor = states['X'][i]
            y_cor = states['Y'][i]
            printer = Print(state_name, x_cor, y_cor)
        # make sure the dict is clear
        states['State Name'].clear()
        states['X'].clear()
        states['Y'].clear()
        break
    else:
        # If the answer is not in the state list, continue the loop,
        # which will prompt again.
        print(f"'{answer_state}' is not a state name. Try again.")
        continue

results = Turtle()
results.hideturtle()
results.penup()  # Ensure that the turtle's movement doesn't draw lines.
results.goto(0, 0)  # Move the turtle to the desired position before writing.
# Now write the score with correct alignment and font spelling.
results.write(arg=f"You got {total_correct} out of 52 states", align="center", font=("Arial", 24, "bold"))

# keep screen up until we are done
screen.exitonclick()
