from turtle import Turtle

class Print(Turtle):
    def __init__(self, text, x, y):
        super().__init__()
        self.hideturtle()
        self.penup()
        self.text = text
        self.x = x
        self.y = y
        self.goto(int(self.x), int(self.y))
        self.print_text()

    def print_text(self):
        self.write(arg=str(self.text), align="center", font=("Arial", 7, "normal"))
